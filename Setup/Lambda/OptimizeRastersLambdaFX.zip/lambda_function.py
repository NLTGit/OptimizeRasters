# ------------------------------------------------------------------------------
# Copyright 2016 Esri
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ------------------------------------------------------------------------------
# Name: lambda_function.py
# Description: AWS Lambda function handler for Optimizesrasters
# Version: 20171227
# Requirements: AWS account to setup
# Required Arguments: N/A
# Optional Arguments: N/A
# Usage: Called via OptimizeRasters.py with op=lambda
# Author: Esri Imagery Workflows Team
# ------------------------------------------------------------------------------
# !/usr/bin/env python

from __future__ import print_function

import json
import os
import OptimizeRasters


def lambda_handler(event, context):
    orjobFile = configFile = None
    if ('Records' in event and
        'Sns' in event['Records'][0] and
            'Message' in event['Records'][0]['Sns']):
        msg = json.loads(event['Records'][0]['Sns']['Message'])
        if ('orjob' in msg):
            orjobFile = '/tmp/{}'.format(msg['orjob']['file'])
            with open(orjobFile, 'w+') as f:
                f.write(msg['orjob']['content'])
        if ('config' in msg):
            configFile = '/tmp/{}'.format(msg['config']['file'])
            with open(configFile, 'w+') as f:
                f.write(msg['config']['content'])
    args = {}
    args['input'] = orjobFile
    args['config'] = configFile
    app = OptimizeRasters.Application(args)
    if (not app.init()):
        return False
    code = app.run()
    RasterProxyFiles = 'rasterproxyfiles'
    RasterProxyPath = 'rasterproxypath'
    response = {RasterProxyFiles: {}, 'status': True}
    rpt = app.getReport()
    if (rpt):
        response['input_list_info'] = rpt._input_list_info  # return file category status
        if (RasterProxyPath in rpt._header):
            proxyPath = rpt._header[RasterProxyPath]
            for r, d, f in os.walk(proxyPath):
                for file in f:
                    readPath = os.path.join(r, file).replace('\\', '/')
                    keyPath = readPath.replace(proxyPath, '')
                    with open(readPath, 'rb') as readPtr:
                        if (keyPath not in response[RasterProxyFiles]):
                            response[RasterProxyFiles][keyPath] = readPtr.read()
        response['status'] = not rpt.hasFailures()
    return response
